| Phar | Discord | HitCount |
| :---: | :---: | :---: |
 [![Download](https://img.shields.io/badge/download-latest-blue.svg)](https://poggit.pmmp.io/ci/CLADevs/Bot) | [![Discord](https://camo.githubusercontent.com/455152269a0ed38255ed15e375084d4dd08e0c98/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f636861742d6f6e253230646973636f72642d3732383944412e737667)](https://discord.gg/xEm5pcM) | [![HitCount](http://hits.dwyl.io/CLADevs/Bot.svg)](http://hits.dwyl.io/CLADevs/Bot)

## Finished
 - [x] Jump
 - [x] Sneak/Unsneak
 - [x] Nametags
 - [x] Spin

 ## Need Help?
  Open an Issue [here](https://github.com/CLADevs/Bot/issues/new).