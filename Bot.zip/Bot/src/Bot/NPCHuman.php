<?php

declare(strict_types=1);

namespace Bot;

use pocketmine\entity\Human;

class NPCHuman extends Human{
}