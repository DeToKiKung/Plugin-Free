<?php

declare(strict_types=1);

namespace Bot\tasks;

use pocketmine\math\Vector2;
use pocketmine\entity\Entity;
use Bot\{
	Main, NPCHuman
};

class JumpTask extends PluginTask {

	private $plugin, $entity;

	public function __construct(Main $plugin, Entity $entity){

		$this->plugin = $plugin;

		$this->entity = $entity;
        parent::__construct($plugin);
	}

	public function onRun(int $tick): void{

		$entity = $this->entity;

		if($entity instanceof NPCHuman){

			$entity->jump();

		}

	}

}

