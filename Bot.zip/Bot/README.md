# Bot Plugin

# TODO
- [x] Particle
- [x] Sneak/Unsneak
- [x] Rotation
- [x] Walking

## Need Help?
  Open an Issue [here](https://github.com/xXNiceYT/Bot/issues/new).

## Credit:
- Slapper